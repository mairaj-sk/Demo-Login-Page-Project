<?php
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $email = $conn->real_escape_string(trim($_POST['email']));
  $password = $conn->real_escape_string(trim($_POST['password']));

  // DANGEROUS: storing password as plain text (for testing only)
  $sql = "INSERT INTO users (email, password) VALUES ('$email', '$password')";

  if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Login successfully!'); window.location.href='index.html';</script>";
  } else {
    echo "Error: " . $conn->error;
  }
} else {
  echo "Invalid request.";
}
$conn->close();
?>