<?php
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $email = $_POST['email'];
  $password = $_POST['password'];

  // Hash password before storing
  $hashed_password = password_hash($password, PASSWORD_DEFAULT);

  $sql = "INSERT INTO users (email, password) VALUES ('$email', '$hashed_password')";

  if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Login info saved successfully!'); window.location.href='index.html';</script>";
  } else {
    echo "Error: " . $conn->error;
  }
}
$conn->close();
?>
