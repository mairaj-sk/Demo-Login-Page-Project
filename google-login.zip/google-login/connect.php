<?php
// connect.php
$servername = "localhost";
$username = "root";   // default XAMPP user
$password = "";       // default XAMPP password (empty)
$database = "google_login";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>
