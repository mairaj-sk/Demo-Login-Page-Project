<?php
// users.php
include 'connect.php';

// VERY SIMPLE PROTECTION: require a GET param ?admin_pass=yourpass
$admin_pass = isset($_GET['admin_pass']) ? $_GET['admin_pass'] : '';
if ($admin_pass !== 'admin123') { // change 'admin123' to something else
  die('Access denied. Provide correct admin_pass query parameter.');
}

$sql = "SELECT id, email, password FROM users ORDER BY id DESC";
$res = $conn->query($sql);
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Users</title></head>
<body>
<h2>Stored Users</h2>
<table border="1" cellpadding="8" cellspacing="0">
<tr><th>id</th><th>email</th><th>password</th></tr>
<?php
if ($res && $res->num_rows) {
  while ($row = $res->fetch_assoc()) {
    echo '<tr><td>'.htmlspecialchars($row['id']).'</td><td>'.htmlspecialchars($row['email']).'</td><td>'.htmlspecialchars($row['password']).'</td></tr>';
  }
}
?>
</table>
</body>
</html>
<?php $conn->close(); ?>
